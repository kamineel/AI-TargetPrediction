﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

using Newtonsoft.Json;
using System.IO;
using System.Net.Http.Formatting;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace NewApp.Controllers
{
    public class ValuesController : ApiController
    {
        // GET api/values
        public IEnumerable<string> Get()
        {
            return new string[] { "lkvalue3", "lkvalue4" };
        }

        // GET api/values/5
        public async Task<string> Get(int id)
        {
            string result = await InvokeScoreService(null, null, id);
            return result;
        }

        // GET api/values/?recipe=Chocolate Soy Milk&parameter=Speed&size=1
        // GET api/values/?recipe=Chocolate Soy Milk&parameter=Speed&size=5
        // GET api/values/?recipe=Cocoa Almond&parameter=Speed&size=1
        // GET api/values/?recipe=Cocoa Almond&parameter=Quantity&size=1
        // GET api/values/?recipe=Chocolate Soy Milk&parameter=Quantity&size=1
        public async Task<string> Get(string recipe, string parameter, int size)
        {
            string result = await InvokeScoreService(recipe.ToString(), parameter.ToString(), size);
            return result;
        }

        // POST api/values
        public void Post([FromBody]string value)
        {
        }

        // PUT api/values/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/values/5
        public void Delete(int id)
        {
        }

        static async Task<string> InvokeScoreService(string recipeName, string parameter, int size)
        {
            string equipmentParameter = string.IsNullOrWhiteSpace(parameter) ? "Speed" : parameter;
            string formulaParameter = "Mix." + equipmentParameter;
            string originalTargetValue = "10";
            string newTargetValue = "0";
            string equipment = "EQ_ChocoMixer";

            string recipe = string.IsNullOrWhiteSpace(recipeName) ? "Chocolate Soy Milk" : recipeName;
            string formula = "Chocolatey";
            string batchSize = size <= 0 ? "1" : size.ToString();
            string uom = "gal";

            using (var client = new HttpClient())
            {
                var scoreRequest = new
                {
                    Inputs = new Dictionary<string, StringTable>() {
                        {
                            "input1",
                            new StringTable()
                            {
                                ColumnNames = new string[] {"EquipmentParameterName", "Operation", "OriginalTargetValue", "NewTargetValue", "EquipmentName", "RecipeName", "FormulaName", "BatchSize", "UnitOfMeasureName"},
                                Values = new string[,] {  
                                        {
                                            equipmentParameter, formulaParameter,
                                            originalTargetValue, newTargetValue,
                                            equipment, recipe, formula,
                                            batchSize, uom
                                        },
                                        {
                                            equipmentParameter, formulaParameter,
                                            originalTargetValue, newTargetValue,
                                            equipment, recipe, formula,
                                            batchSize, uom
                                        }
                                }
                            }
                        },
                    },
                    GlobalParameters = new Dictionary<string, string>()
                    {
                    }
                };

                const string apiKey = "DjllfSaQHfiUFz7JCry3UetNdSDxtKtkkg1TZhd75VJzpng65HUQWGmQ0vHwXQ60t4JEjxeeET8PM7OVnRxb6w=="; // Replace this with the API key for the web service
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", apiKey);
                // client.BaseAddress = new Uri("https://ussouthcentral.services.azureml.net/workspaces/e672101786074bdfa53e33ec863ae0c5/services/8447e76158cb4c308ecc8cae4720f1ce/execute?api-version=2.0&details=true");
                client.BaseAddress = new Uri("https://ussouthcentral.services.azureml.net/workspaces/e672101786074bdfa53e33ec863ae0c5/services/230967c1492d4bfb8b9126574035485e/execute?api-version=2.0&details=true");

                HttpResponseMessage response = await client.PostAsJsonAsync("", scoreRequest);

                string value = scoreRequest.Inputs["input1"].Values[1, 7];
                if (response.IsSuccessStatusCode)
                {
                    string json = await response.Content.ReadAsStringAsync();
                    RootObject r = JsonConvert.DeserializeObject<RootObject>(json);

                    string result = r.Results.output1.value.Values[0].LastOrDefault();
                    return result;
                }
                else
                {
                    string responseContent = await response.Content.ReadAsStringAsync();
                    return responseContent;
                }
            }
        }
        public class StringTable
        {
            public string[] ColumnNames { get; set; }
            public string[,] Values { get; set; }
        }

        public class Value
        {
            public List<string> ColumnNames { get; set; }
            public List<string> ColumnTypes { get; set; }
            public List<List<string>> Values { get; set; }
        }

        public class Output1
        {
            public string type { get; set; }
            public Value value { get; set; }
        }

        public class Results
        {
            public Output1 output1 { get; set; }
        }

        public class RootObject
        {
            public Results Results { get; set; }
        }
    }
}
